# Xây Dựng ROM GSI 
Điều Kiện:
- Có một trình duyệt wed ổn định đảm bảo quá trình diễn ra suôn sẻ
- Trong lúc diễn ra quá trình không được tắt màn hình hoặc chuyển sang tác vụ khác vì điều này dễ gây ra lỗi
- Link ROM phải One Click ấn phát tải ngay 
- Định dạng ROM.zip
- ROM phải hỗ trợ treble
### URL ROM One Click ( Ví dụ )
```
https://srv-file19.gofile.io/download/u5xlHf/OmniROM-AB-10-202008030953-ErfanGSI.7z
```
### Các định dạng ROM thiết lập bắt buộc:
9 Pie：
ColorOS Flyme Generic MIUI Moto Nubia OneUI OxygenOS Pixel Xperia ZUI ZenUI

10 Q：
Generic MIUI OxygenOS Pixel

11 R：
Generic Pixel
 
# Video hướng dẫn:
https://youtu.be/rRSf-d-NZdU
# Câu nói truyền động lực:
```
Trên bước đường thành công, không có dấu chân của kẻ lười biếng vì kẻ lười biếng có đi đâu mà có dấu chân :v
```
# Hỗ trợ:
- Tham Gia Group Redesign - Nơi Tái Chế System: https://t.me/systempublictaiche
- Youtube: https://www.youtube.com/channel/UCp-a_8f9Zn6yqb_7W-LS-Gw?view_as=subscriber
- Facebook: https://www.facebook.com/toan704
# CHÚC CÁC BẠN THÀNH CÔNG! 
![image](https://user-images.githubusercontent.com/67217560/88624265-dc899300-d0d0-11ea-99bd-85cc9bb2c331.png)
